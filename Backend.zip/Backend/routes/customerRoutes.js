import express from "express";

import {
  createCustomer,
  getCustomers,
  getCustomerById,
  updateCustomer,
  deleteCustomer,
} from "../controllers/customer/customerController.js";

import {
  protect,
  adminOnly,
  staffOrAdmin,
} from "../middleware/authMiddleware.js";

const router = express.Router();

// Admin + Staff

router.post(
  "/",
  protect,
  staffOrAdmin,
  createCustomer
);

router.get(
  "/",
  protect,
  staffOrAdmin,
  getCustomers
);

router.get(
  "/:id",
  protect,
  staffOrAdmin,
  getCustomerById
);

router.put(
  "/:id",
  protect,
  staffOrAdmin,
  updateCustomer
);

// Admin only

router.delete(
  "/:id",
  protect,
  adminOnly,
  deleteCustomer
);

export default router;