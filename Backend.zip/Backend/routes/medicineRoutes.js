import express from "express";

import {
  getMedicines,
  getMedicineById,
  addMedicine,
  updateMedicine,
  deleteMedicine,
} from "../controllers/medicineController.js";

import {
  protect,
  adminOnly,
  staffOrAdmin,
} from "../middleware/authMiddleware.js";

const router = express.Router();

// Admin + Staff
router.get(
  "/",
  protect,
  staffOrAdmin,
  getMedicines
);

router.get(
  "/:id",
  protect,
  staffOrAdmin,
  getMedicineById
);

router.post(
  "/",
  protect,
  staffOrAdmin,
  addMedicine
);

router.put(
  "/:id",
  protect,
  staffOrAdmin,
  updateMedicine
);

// Admin only
router.delete(
  "/:id",
  protect,
  adminOnly,
  deleteMedicine
);

export default router;