import express from "express";

import {
  createInvoice,
  getInvoices,
  getInvoiceById,
  deleteInvoice,
} from "../controllers/invoice/invoiceController.js";

const router = express.Router();

// ======================================
// Create Invoice
// ======================================

router.post("/", createInvoice);

// ======================================
// Get All Invoices
// ======================================

router.get("/", getInvoices);

// ======================================
// Get Single Invoice
// ======================================

router.get("/:id", getInvoiceById);

// ======================================
// Delete Invoice
// ======================================

router.delete("/:id", deleteInvoice);

export default router;