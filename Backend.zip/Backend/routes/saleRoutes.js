import express from "express";
import {
  getSales,
  createSale,
  getTodaySales,
  getSalesSummary,
} from "../controllers/saleController.js";

const router = express.Router();

// Get All Sales
router.get("/", getSales);

// Today's Sales
router.get("/today", getTodaySales);

// Sales Summary
router.get("/summary", getSalesSummary);

// Create New Sale
router.post("/", createSale);

export default router;