import express from "express";
import dotenv from "dotenv";
import cors from "cors";

import connectDB from "./config/db.js";

import medicineRoutes from "./routes/medicineRoutes.js";
import saleRoutes from "./routes/saleRoutes.js";
import reportRoutes from "./routes/reportRoutes.js";
import invoiceRoutes from "./routes/invoiceRoutes.js";
import customerRoutes from "./routes/customerRoutes.js";
import authRoutes from "./routes/authRoutes.js";

dotenv.config();

connectDB();

const app = express();

// ==========================
// Middleware
// ==========================

app.use(cors());

app.use(express.json());

// ==========================
// API Routes
// ==========================

app.use("/api/medicines", medicineRoutes);

app.use("/api/sales", saleRoutes);

app.use("/api/reports", reportRoutes);

app.use("/api/invoices", invoiceRoutes);

app.use("/api/customers", customerRoutes);

app.use("/api/auth", authRoutes);

// ==========================
// Default Route
// ==========================

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Pharmacy Management API Running 🚀",
  });
});

// ==========================
// 404 Route
// ==========================

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route Not Found",
  });
});

// ==========================
// Start Server
// ==========================

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server Running on Port ${PORT}`);
});