import Sale from "../models/Sale.js";

export const getSalesReport = async (req, res) => {
  try {
    const { filter, from, to } = req.query;

    let startDate;
    let endDate = new Date();

    switch (filter) {
      case "today":
        startDate = new Date();
        startDate.setHours(0, 0, 0, 0);
        break;

      case "yesterday":
        startDate = new Date();
        startDate.setDate(startDate.getDate() - 1);
        startDate.setHours(0, 0, 0, 0);

        endDate = new Date(startDate);
        endDate.setHours(23, 59, 59, 999);
        break;

      case "week":
        startDate = new Date();
        startDate.setDate(startDate.getDate() - 6);
        startDate.setHours(0, 0, 0, 0);
        break;

      case "month":
        startDate = new Date(
          endDate.getFullYear(),
          endDate.getMonth(),
          1
        );
        break;

      case "year":
        startDate = new Date(
          endDate.getFullYear(),
          0,
          1
        );
        break;

      case "custom":
        startDate = new Date(from);
        endDate = new Date(to);
        endDate.setHours(23, 59, 59, 999);
        break;

      default:
        startDate = new Date();
        startDate.setHours(0, 0, 0, 0);
    }

    const sales = await Sale.find({
      createdAt: {
        $gte: startDate,
        $lte: endDate,
      },
    }).sort({ createdAt: -1 });

    const revenue = sales.reduce(
      (sum, sale) => sum + sale.total,
      0
    );

    const medicines = sales.reduce(
      (sum, sale) => sum + sale.quantity,
      0
    );

    res.json({
      success: true,

      summary: {
        revenue,
        sales: sales.length,
        medicines,
      },

      sales,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};