import Invoice from "../../models/Invoice.js";
import Medicine from "../../models/Medicine.js";
import Customer from "../../models/Customer.js";
import Sale from "../../models/Sale.js";

// ======================================
// Generate Invoice Number
// ======================================

const generateInvoiceNumber = async () => {
  const lastInvoice = await Invoice.findOne()
    .sort({ createdAt: -1 })
    .select("invoiceNumber");

  if (!lastInvoice) {
    return "INV-000001";
  }

  const lastNumber = parseInt(
    lastInvoice.invoiceNumber.replace("INV-", ""),
    10
  );

  const nextNumber = lastNumber + 1;

  return `INV-${String(nextNumber).padStart(6, "0")}`;
};

// ======================================
// CREATE INVOICE
// ======================================

export const createInvoice = async (req, res) => {
  try {
    const {
      customerId,
      items,
      discount = 0,
      tax = 0,
      paymentMethod = "Cash",
      paymentStatus = "Paid",
    } = req.body;

    // ==================================
    // Validate Items
    // ==================================

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "At least one medicine is required",
      });
    }

    // ==================================
    // Customer
    // ==================================

    let customerName = "Walk-in Customer";
    let customerPhone = "";

    if (customerId) {
      const customer = await Customer.findById(customerId);

      if (!customer) {
        return res.status(404).json({
          success: false,
          message: "Customer not found",
        });
      }

      customerName = customer.name;
      customerPhone = customer.phone;
    }

    // ==================================
    // Validate Medicines & Prepare Items
    // ==================================

    const invoiceItems = [];
    let subtotal = 0;

    for (const item of items) {
      const medicine = await Medicine.findById(
        item.medicineId
      );

      if (!medicine) {
        return res.status(404).json({
          success: false,
          message: `Medicine not found: ${item.medicineId}`,
        });
      }

      const quantity = Number(item.quantity);

      if (!Number.isInteger(quantity) || quantity <= 0) {
        return res.status(400).json({
          success: false,
          message: `Invalid quantity for ${medicine.name}`,
        });
      }

      if (medicine.quantity < quantity) {
        return res.status(400).json({
          success: false,
          message: `Not enough stock for ${medicine.name}. Available: ${medicine.quantity}`,
        });
      }

      const price = Number(medicine.price);
      const total = price * quantity;

      subtotal += total;

      invoiceItems.push({
        medicineId: medicine._id,
        medicineName: medicine.name,
        company: medicine.company || "",
        quantity,
        price,
        total,
      });
    }

    // ==================================
    // Calculate Total
    // ==================================

    const discountAmount = Math.max(
      0,
      Number(discount) || 0
    );

    const taxAmount = Math.max(
      0,
      Number(tax) || 0
    );

    if (discountAmount > subtotal) {
      return res.status(400).json({
        success: false,
        message: "Discount cannot be greater than subtotal",
      });
    }

    const grandTotal =
      subtotal - discountAmount + taxAmount;

    if (grandTotal < 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid invoice total",
      });
    }

    // ==================================
    // Generate Invoice Number
    // ==================================

    const invoiceNumber =
      await generateInvoiceNumber();

    // ==================================
    // Create Invoice
    // ==================================

    const invoice = await Invoice.create({
      invoiceNumber,
      customerId: customerId || null,
      customerName,
      customerPhone,
      items: invoiceItems,
      subtotal,
      discount: discountAmount,
      tax: taxAmount,
      grandTotal,
      paymentMethod,
      paymentStatus,
    });

    const createdSales = [];
    const stockChanges = [];

    try {
      // ==================================
      // Create Sales + Reduce Stock Once
      // ==================================

      for (const item of invoiceItems) {
        const updatedMedicine =
          await Medicine.findOneAndUpdate(
            {
              _id: item.medicineId,
              quantity: { $gte: item.quantity },
            },
            {
              $inc: {
                quantity: -item.quantity,
              },
            },
            {
              new: true,
            }
          );

        if (!updatedMedicine) {
          throw new Error(
            `Stock changed while creating invoice for ${item.medicineName}. Please try again.`
          );
        }

        stockChanges.push({
          medicineId: item.medicineId,
          quantity: item.quantity,
        });

        const sale = await Sale.create({
          invoiceId: invoice._id,
          medicineId: item.medicineId,
          medicineName: item.medicineName,
          company: item.company || "",
          quantity: item.quantity,
          price: item.price,
          total: item.total,
        });

        createdSales.push(sale._id);
      }

      // ==================================
      // Success
      // ==================================

      res.status(201).json({
        success: true,
        message: "Invoice created successfully",
        invoice,
      });

    } catch (transactionError) {
      // ==================================
      // Rollback Sales
      // ==================================

      if (createdSales.length > 0) {
        await Sale.deleteMany({
          _id: { $in: createdSales },
        });
      }

      // ==================================
      // Rollback Stock
      // ==================================

      for (const change of stockChanges) {
        await Medicine.findByIdAndUpdate(
          change.medicineId,
          {
            $inc: {
              quantity: change.quantity,
            },
          }
        );
      }

      // ==================================
      // Rollback Invoice
      // ==================================

      await Invoice.findByIdAndDelete(invoice._id);

      throw transactionError;
    }

  } catch (error) {
    console.error(
      "Create Invoice Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ======================================
// GET ALL INVOICES
// ======================================

export const getInvoices = async (req, res) => {
  try {
    const invoices = await Invoice.find()
      .populate("customerId")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      invoices,
    });
  } catch (error) {
    console.error(
      "Get Invoices Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ======================================
// GET SINGLE INVOICE
// ======================================

export const getInvoiceById = async (req, res) => {
  try {
    const invoice = await Invoice.findById(
      req.params.id
    ).populate("customerId");

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: "Invoice not found",
      });
    }

    res.status(200).json({
      success: true,
      invoice,
    });
  } catch (error) {
    console.error(
      "Get Invoice Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ======================================
// DELETE INVOICE
// ======================================

export const deleteInvoice = async (req, res) => {
  try {
    const invoice = await Invoice.findById(
      req.params.id
    );

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: "Invoice not found",
      });
    }

    // ==================================
    // Restore Stock
    // ==================================

    for (const item of invoice.items) {
      await Medicine.findByIdAndUpdate(
        item.medicineId,
        {
          $inc: {
            quantity: item.quantity,
          },
        }
      );
    }

    // ==================================
    // Delete Only This Invoice's Sales
    // ==================================

    await Sale.deleteMany({
      invoiceId: invoice._id,
    });

    // ==================================
    // Delete Invoice
    // ==================================

    await invoice.deleteOne();

    res.status(200).json({
      success: true,
      message:
        "Invoice deleted, related sales deleted and stock restored",
    });

  } catch (error) {
    console.error(
      "Delete Invoice Error:",
      error
    );

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};