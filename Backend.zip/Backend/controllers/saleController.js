import Sale from "../models/Sale.js";
import Medicine from "../models/Medicine.js";

// =========================
// Get All Sales
// =========================
export const getSales = async (req, res) => {
  try {
    const sales = await Sale.find().sort({ createdAt: -1 });

    res.status(200).json(sales);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// =========================
// Create Sale
// =========================
export const createSale = async (req, res) => {
  try {
    const { medicineId, quantity } = req.body;

    const medicine = await Medicine.findById(medicineId);

    if (!medicine) {
      return res.status(404).json({
        success: false,
        message: "Medicine not found",
      });
    }

    if (quantity <= 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid quantity",
      });
    }

    if (medicine.quantity < quantity) {
      return res.status(400).json({
        success: false,
        message: "Not enough stock available",
      });
    }

    const total = medicine.price * quantity;

    const sale = await Sale.create({
      medicineId: medicine._id,
      medicineName: medicine.name,
      company: medicine.company,
      quantity,
      price: medicine.price,
      total,
    });

    medicine.quantity -= quantity;
    await medicine.save();

    res.status(201).json({
      success: true,
      message: "Sale completed successfully",
      sale,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// =========================
// Today's Sales
// =========================
export const getTodaySales = async (req, res) => {
  try {
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    const end = new Date();
    end.setHours(23, 59, 59, 999);

    const sales = await Sale.find({
      createdAt: {
        $gte: start,
        $lte: end,
      },
    });

    const revenue = sales.reduce(
      (sum, sale) => sum + sale.total,
      0
    );

    const medicines = sales.reduce(
      (sum, sale) => sum + sale.quantity,
      0
    );

    res.json({
      totalSales: sales.length,
      totalRevenue: revenue,
      totalMedicines: medicines,
      sales,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// =========================
// Sales Summary
// =========================
export const getSalesSummary = async (req, res) => {
  try {
    const now = new Date();

    // Today
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);

    // Yesterday
    const yesterdayStart = new Date(todayStart);
    yesterdayStart.setDate(yesterdayStart.getDate() - 1);

    const yesterdayEnd = new Date(todayStart);

    // Week
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - 6);
    weekStart.setHours(0, 0, 0, 0);

    // Month
    const monthStart = new Date(
      now.getFullYear(),
      now.getMonth(),
      1
    );

    const allSales = await Sale.find();

    const todaySales = await Sale.find({
      createdAt: { $gte: todayStart },
    });

    const yesterdaySales = await Sale.find({
      createdAt: {
        $gte: yesterdayStart,
        $lt: yesterdayEnd,
      },
    });

    const weekSales = await Sale.find({
      createdAt: { $gte: weekStart },
    });

    const monthSales = await Sale.find({
      createdAt: { $gte: monthStart },
    });

    const getRevenue = (sales) =>
      sales.reduce((sum, sale) => sum + sale.total, 0);

    res.status(200).json({
      todayRevenue: getRevenue(todaySales),
      yesterdayRevenue: getRevenue(yesterdaySales),
      weekRevenue: getRevenue(weekSales),
      monthRevenue: getRevenue(monthSales),
      totalRevenue: getRevenue(allSales),

      todaySales: todaySales.length,
      yesterdaySales: yesterdaySales.length,
      weekSales: weekSales.length,
      monthSales: monthSales.length,
      totalSales: allSales.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};