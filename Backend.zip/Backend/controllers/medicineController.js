import Medicine from "../models/Medicine.js";

// GET All Medicines
export const getMedicines = async (req, res) => {
  try {
    const medicines = await Medicine.find().sort({ createdAt: -1 });
    res.status(200).json(medicines);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ADD Medicine
export const addMedicine = async (req, res) => {
  try {
    console.log("Received Data:", req.body);

    const medicine = await Medicine.create({
      name: req.body.name,
      company: req.body.company,
      category: req.body.category,
      price: Number(req.body.price),
      quantity: Number(req.body.quantity),
      expiry: req.body.expiry,
    });

    res.status(201).json(medicine);
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// DELETE Medicine
export const deleteMedicine = async (req, res) => {
  try {
    await Medicine.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: "Medicine Deleted",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET Single Medicine
export const getMedicineById = async (req, res) => {
  try {
    const medicine = await Medicine.findById(req.params.id);

    if (!medicine) {
      return res.status(404).json({
        message: "Medicine not found",
      });
    }

    res.json(medicine);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// UPDATE Medicine
export const updateMedicine = async (req, res) => {
  try {
    const medicine = await Medicine.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    if (!medicine) {
      return res.status(404).json({
        message: "Medicine not found",
      });
    }

    res.json(medicine);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};