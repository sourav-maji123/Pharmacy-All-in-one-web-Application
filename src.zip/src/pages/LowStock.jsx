import { useEffect, useState } from "react";
import api from "../services/api";

function LowStock() {
  const [medicines, setMedicines] = useState([]);

  useEffect(() => {
    fetchLowStock();
  }, []);

  const fetchLowStock = async () => {
    try {
      const res = await api.get("/medicines");

      const lowStockMedicines = res.data.filter(
        (medicine) => Number(medicine.quantity) <= 10
      );

      setMedicines(lowStockMedicines);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold text-slate-800">
          Low Stock Medicines
        </h1>

        <p className="text-gray-500 mt-2">
          Medicines with quantity less than or equal to 10.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-md overflow-x-auto">

        <table className="w-full">

          <thead className="bg-orange-500 text-white">

            <tr>
              <th className="p-3">Medicine</th>
              <th>Company</th>
              <th>Category</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Expiry</th>
            </tr>

          </thead>

          <tbody>

            {medicines.length === 0 ? (

              <tr>
                <td
                  colSpan="6"
                  className="text-center p-6"
                >
                  No Low Stock Medicines 🎉
                </td>
              </tr>

            ) : (

              medicines.map((medicine) => (

                <tr
                  key={medicine._id}
                  className="border-b text-center hover:bg-gray-50"
                >
                  <td className="p-3 font-semibold">
                    {medicine.name}
                  </td>

                  <td>{medicine.company}</td>

                  <td>{medicine.category}</td>

                  <td>₹{medicine.price}</td>

                  <td className="text-red-600 font-bold">
                    {medicine.quantity}
                  </td>

                  <td>
                    {new Date(
                      medicine.expiry
                    ).toLocaleDateString()}
                  </td>

                </tr>

              ))

            )}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default LowStock;