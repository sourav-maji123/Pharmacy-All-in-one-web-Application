import { useState } from "react";

import CustomerForm from "../../components/customer/CustomerForm";
import CustomerTable from "../../components/customer/CustomerTable";

function Customers() {
  const [refresh, setRefresh] = useState(0);

  const handleCustomerAdded = () => {
    setRefresh((prev) => prev + 1);
  };

  return (
    <div className="space-y-6">

      {/* =========================
          PAGE HEADER
      ========================= */}

      <div>
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
          Customer Management
        </h1>

        <p className="text-gray-500 dark:text-gray-400 mt-1">
          Manage pharmacy customers and their information.
        </p>
      </div>

      {/* =========================
          ADD CUSTOMER
      ========================= */}

      <CustomerForm
        onCustomerAdded={handleCustomerAdded}
      />

      {/* =========================
          CUSTOMER TABLE
      ========================= */}

      <CustomerTable refresh={refresh} />

    </div>
  );
}

export default Customers;