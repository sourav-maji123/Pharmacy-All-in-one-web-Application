import { useParams } from "react-router-dom";
import MedicineForm from "../components/medicine/MedicineForm";

function EditMedicine() {
  const { id } = useParams();

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">
        Edit Medicine
      </h1>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <MedicineForm editId={id} />
      </div>
    </div>
  );
}

export default EditMedicine;