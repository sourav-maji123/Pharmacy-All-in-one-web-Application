import RegisterForm from "../../components/auth/RegisterForm";

function Register() {
  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 flex items-center justify-center px-4">

      <div className="w-full max-w-md">

        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8">

          <div className="text-center mb-8">
            <div className="text-5xl mb-4">
              💊
            </div>

            <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
              Create Account
            </h1>

            <p className="text-gray-500 dark:text-gray-400 mt-2">
              Register for Pharmacy Management System
            </p>
          </div>

          <RegisterForm />

        </div>

      </div>

    </div>
  );
}

export default Register;