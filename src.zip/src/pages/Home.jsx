function Home() {
  return (
    <div>
      <h1>Welcome</h1>
      <p>Pharmacy Stock & Expiry Tracker</p>
    </div>
  );
}

export default Home;