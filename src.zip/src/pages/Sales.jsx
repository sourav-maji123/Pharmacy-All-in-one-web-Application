import { useState } from "react";

import SalesFilter from "../components/sales/SalesFilter";
import SalesCard from "../components/sales/SalesCard";
import SalesTable from "../components/sales/SalesTable";

function Sales() {
  const [filter, setFilter] = useState("today");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  return (
    <div className="space-y-6">

      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
          Sales Management
        </h1>

        <p className="text-gray-500 dark:text-gray-400 mt-2">
          View sales reports and revenue analytics.
        </p>
      </div>

      {/* Filter */}
      <SalesFilter
        filter={filter}
        setFilter={setFilter}
        fromDate={fromDate}
        setFromDate={setFromDate}
        toDate={toDate}
        setToDate={setToDate}
      />

      {/* Cards */}
      <SalesCard
        filter={filter}
        fromDate={fromDate}
        toDate={toDate}
      />

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-5">
        <SalesTable
          filter={filter}
          fromDate={fromDate}
          toDate={toDate}
        />
      </div>

    </div>
  );
}

export default Sales;