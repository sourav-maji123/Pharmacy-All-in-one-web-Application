import MedicineForm from "../components/medicine/MedicineForm";

function AddMedicine() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-slate-800 mb-6">
        Add Medicine
      </h1>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <MedicineForm />
      </div>
    </div>
  );
}

export default AddMedicine;