import { useEffect, useState } from "react";
import api from "../../services/api";
import InvoiceTable from "../../components/billing/InvoiceTable";

function Billing() {
  const [customers, setCustomers] = useState([]);
  const [medicines, setMedicines] = useState([]);

  const [customerId, setCustomerId] = useState("");
  const [selectedMedicine, setSelectedMedicine] = useState("");
  const [quantity, setQuantity] = useState(1);

  const [items, setItems] = useState([]);

  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState("Cash");

  const [loading, setLoading] = useState(false);
  const [invoiceRefresh, setInvoiceRefresh] = useState(0);

  // ==========================================
  // FETCH CUSTOMERS & MEDICINES
  // ==========================================

  useEffect(() => {
    fetchCustomers();
    fetchMedicines();
  }, []);

  const fetchCustomers = async () => {
    try {
      const res = await api.get("/customers");
      setCustomers(res.data.customers || []);
    } catch (error) {
      console.error("Customer Fetch Error:", error);
    }
  };

  const fetchMedicines = async () => {
    try {
      const res = await api.get("/medicines");
      setMedicines(res.data || []);
    } catch (error) {
      console.error("Medicine Fetch Error:", error);
    }
  };

  // ==========================================
  // ADD MEDICINE
  // ==========================================

  const addMedicine = () => {
    if (!selectedMedicine) {
      alert("Please select a medicine");
      return;
    }

    const medicine = medicines.find(
      (m) => m._id === selectedMedicine
    );

    if (!medicine) return;

    const qty = Number(quantity);

    if (!Number.isInteger(qty) || qty <= 0) {
      alert("Please enter a valid quantity");
      return;
    }

    if (qty > medicine.quantity) {
      alert("Not enough stock available");
      return;
    }

    const existingItem = items.find(
      (item) => item.medicineId === medicine._id
    );

    if (existingItem) {
      const newQuantity =
        existingItem.quantity + qty;

      if (newQuantity > medicine.quantity) {
        alert("Not enough stock available");
        return;
      }

      setItems(
        items.map((item) =>
          item.medicineId === medicine._id
            ? {
                ...item,
                company: medicine.company || "",
                quantity: newQuantity,
                total: medicine.price * newQuantity,
              }
            : item
        )
      );
    } else {
      setItems([
        ...items,
        {
          medicineId: medicine._id,
          medicineName: medicine.name,
          company: medicine.company || "",
          quantity: qty,
          price: medicine.price,
          total: medicine.price * qty,
        },
      ]);
    }

    setSelectedMedicine("");
    setQuantity(1);
  };

  // ==========================================
  // REMOVE MEDICINE
  // ==========================================

  const removeItem = (medicineId) => {
    setItems(
      items.filter(
        (item) => item.medicineId !== medicineId
      )
    );
  };

  // ==========================================
  // CALCULATIONS
  // ==========================================

  const subtotal = items.reduce(
    (sum, item) => sum + item.total,
    0
  );

  const discountAmount = Math.max(
    0,
    Number(discount) || 0
  );

  const taxAmount = Math.max(
    0,
    Number(tax) || 0
  );

  const grandTotal =
    subtotal - discountAmount + taxAmount;

  // ==========================================
  // GENERATE INVOICE
  // ==========================================

  const generateInvoice = async () => {
    if (items.length === 0) {
      alert("Please add at least one medicine");
      return;
    }

    if (discountAmount > subtotal) {
      alert("Discount cannot be greater than subtotal");
      return;
    }

    try {
      setLoading(true);

      const res = await api.post("/invoices", {
        customerId: customerId || null,
        items,
        discount: discountAmount,
        tax: taxAmount,
        paymentMethod,
        paymentStatus: "Paid",
      });

      alert(
        res.data.message ||
          "Invoice generated successfully"
      );

      // Clear form
      setCustomerId("");
      setSelectedMedicine("");
      setQuantity(1);
      setItems([]);
      setDiscount(0);
      setTax(0);
      setPaymentMethod("Cash");

      // Refresh medicines
      await fetchMedicines();

      // Refresh invoice table
      setInvoiceRefresh((prev) => prev + 1);

    } catch (error) {
      console.error(
        "Invoice Generate Error:",
        error
      );

      alert(
        error.response?.data?.message ||
          "Failed to generate invoice"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">

      {/* PAGE HEADER */}

      <div>
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white">
          Billing
        </h1>

        <p className="text-gray-500 dark:text-gray-400 mt-1">
          Create pharmacy invoices and manage payments.
        </p>
      </div>

      {/* CUSTOMER */}

      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-6">

        <h2 className="text-xl font-bold dark:text-white mb-5">
          Customer Details
        </h2>

        <select
          value={customerId}
          onChange={(e) =>
            setCustomerId(e.target.value)
          }
          className="w-full border rounded-lg px-4 py-3 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
        >
          <option value="">
            Walk-in Customer
          </option>

          {customers.map((customer) => (
            <option
              key={customer._id}
              value={customer._id}
            >
              {customer.name} - {customer.phone}
            </option>
          ))}
        </select>

      </div>

      {/* ADD MEDICINE */}

      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-6">

        <h2 className="text-xl font-bold dark:text-white mb-5">
          Add Medicine
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

          <select
            value={selectedMedicine}
            onChange={(e) =>
              setSelectedMedicine(e.target.value)
            }
            className="border rounded-lg px-4 py-3 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
          >
            <option value="">
              Select Medicine
            </option>

            {medicines.map((medicine) => (
              <option
                key={medicine._id}
                value={medicine._id}
              >
                {medicine.name} — ₹{medicine.price} (
                Stock: {medicine.quantity})
              </option>
            ))}
          </select>

          <input
            type="number"
            min="1"
            value={quantity}
            onChange={(e) =>
              setQuantity(Number(e.target.value))
            }
            className="border rounded-lg px-4 py-3 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            placeholder="Quantity"
          />

          <button
            onClick={addMedicine}
            className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold px-5 py-3"
          >
            + Add Medicine
          </button>

        </div>

      </div>

      {/* BILL TABLE */}

      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md overflow-x-auto">

        <table className="w-full">

          <thead className="bg-blue-600 text-white">
            <tr>
              <th className="p-3 text-left">
                Medicine
              </th>

              <th className="text-left">
                Company
              </th>

              <th className="text-center">
                Qty
              </th>

              <th className="text-center">
                Price
              </th>

              <th className="text-center">
                Total
              </th>

              <th className="text-center">
                Action
              </th>
            </tr>
          </thead>

          <tbody>

            {items.length === 0 ? (
              <tr>
                <td
                  colSpan="6"
                  className="text-center p-10 text-gray-500"
                >
                  No medicines added to bill
                </td>
              </tr>
            ) : (
              items.map((item) => (
                <tr
                  key={item.medicineId}
                  className="border-b dark:border-slate-700"
                >

                  <td className="p-3 font-medium dark:text-white">
                    {item.medicineName}
                  </td>

                  <td className="dark:text-white">
                    {item.company || "-"}
                  </td>

                  <td className="text-center dark:text-white">
                    {item.quantity}
                  </td>

                  <td className="text-center dark:text-white">
                    ₹{item.price}
                  </td>

                  <td className="text-center font-semibold dark:text-white">
                    ₹{item.total}
                  </td>

                  <td className="text-center">

                    <button
                      onClick={() =>
                        removeItem(item.medicineId)
                      }
                      className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded"
                    >
                      Remove
                    </button>

                  </td>

                </tr>
              ))
            )}

          </tbody>

        </table>

      </div>

      {/* BILL SUMMARY */}

      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-6">

        <div className="max-w-md ml-auto space-y-4">

          <div className="flex justify-between">
            <span className="text-gray-500">
              Subtotal
            </span>

            <span className="font-semibold dark:text-white">
              ₹{subtotal.toFixed(2)}
            </span>
          </div>

          <div className="flex items-center justify-between gap-4">

            <span className="text-gray-500">
              Discount
            </span>

            <input
              type="number"
              min="0"
              value={discount}
              onChange={(e) =>
                setDiscount(
                  Number(e.target.value)
                )
              }
              className="w-32 border rounded-lg px-3 py-2 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            />

          </div>

          <div className="flex items-center justify-between gap-4">

            <span className="text-gray-500">
              Tax
            </span>

            <input
              type="number"
              min="0"
              value={tax}
              onChange={(e) =>
                setTax(Number(e.target.value))
              }
              className="w-32 border rounded-lg px-3 py-2 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            />

          </div>

          <div className="border-t dark:border-slate-700 pt-4 flex justify-between">

            <span className="text-xl font-bold dark:text-white">
              Grand Total
            </span>

            <span className="text-2xl font-bold text-green-600">
              ₹{grandTotal.toFixed(2)}
            </span>

          </div>

          <div>

            <label className="block mb-2 font-medium dark:text-white">
              Payment Method
            </label>

            <select
              value={paymentMethod}
              onChange={(e) =>
                setPaymentMethod(e.target.value)
              }
              className="w-full border rounded-lg px-4 py-3 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            >
              <option value="Cash">
                Cash
              </option>

              <option value="UPI">
                UPI
              </option>

              <option value="Card">
                Card
              </option>
            </select>

          </div>

          <button
            onClick={generateInvoice}
            disabled={
              loading ||
              items.length === 0
            }
            className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg"
          >
            {loading
              ? "Generating..."
              : "Generate Invoice"}
          </button>

        </div>

      </div>

      {/* INVOICE HISTORY */}

      <InvoiceTable key={invoiceRefresh} />

    </div>
  );
}

export default Billing;