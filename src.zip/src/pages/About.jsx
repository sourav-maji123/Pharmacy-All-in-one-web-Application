
function About() {
  return (
    <div>

      <h1 className="text-3xl font-bold">
        About Project
      </h1>

      <p className="mt-4 text-gray-600">
        <strong>About Us</strong>
        <br /><br />

        <strong>Unisource Tradelink Enterprise</strong>
        <br /><br />

        At Unisource Tradelink Enterprise, we are committed to providing
        smart, reliable, and efficient digital solutions for modern
        pharmacy management.

        <br /><br />

        Our Pharmacy Management System is designed to simplify daily
        pharmacy operations, including medicine inventory management,
        stock monitoring, expiry date tracking, and medicine record
        management.

        <br /><br />

        Our goal is to help pharmacies improve operational efficiency,
        reduce manual errors, prevent medicine wastage, and maintain
        accurate inventory records through a user-friendly digital platform.

        <br /><br />

        <strong>Our Mission</strong>
        <br />

        To make pharmacy management smarter, easier, and more efficient
        through innovative technology.

        <br /><br />

        <strong>Our Vision</strong>
        <br />

        To become a trusted provider of digital management solutions
        that support businesses in their digital transformation journey.

        <br /><br />

        <strong>Developed & Managed by:</strong>
        <br />

        Unisource Tradelink Enterprise

        <br /><br />

        <strong>Email:</strong>
        <br />

        unisourcetradelinkenterprise@gmail.com

        <br /><br />

        © 2026 Unisource Tradelink Enterprise. All Rights Reserved.
      </p>

    </div>
  );
}

export default About;
