import { useEffect, useState } from "react";
import api from "../services/api";

function ExpiredMedicines() {
  const [expiredMedicines, setExpiredMedicines] = useState([]);

  useEffect(() => {
    fetchExpiredMedicines();
  }, []);

  const fetchExpiredMedicines = async () => {
    try {
      const res = await api.get("/medicines");

      const today = new Date();

      const expired = res.data.filter(
        (medicine) => new Date(medicine.expiry) < today
      );

      setExpiredMedicines(expired);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">

      <div>
        <h1 className="text-3xl font-bold text-slate-800">
          Expired Medicines
        </h1>

        <p className="text-gray-500 mt-2">
          Medicines whose expiry date has passed.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-md overflow-x-auto">

        <table className="w-full">

          <thead className="bg-red-600 text-white">
            <tr>
              <th className="p-3">Medicine</th>
              <th>Company</th>
              <th>Category</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Expiry</th>
            </tr>
          </thead>

          <tbody>

            {expiredMedicines.length === 0 ? (
              <tr>
                <td colSpan="6" className="text-center p-6">
                  No Expired Medicines 🎉
                </td>
              </tr>
            ) : (
              expiredMedicines.map((medicine) => (
                <tr
                  key={medicine._id}
                  className="border-b text-center hover:bg-gray-50"
                >
                  <td className="p-3 font-semibold">
                    {medicine.name}
                  </td>

                  <td>{medicine.company}</td>

                  <td>{medicine.category}</td>

                  <td>₹{medicine.price}</td>

                  <td>{medicine.quantity}</td>

                  <td className="text-red-600 font-bold">
                    {new Date(medicine.expiry).toLocaleDateString()}
                  </td>
                </tr>
              ))
            )}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default ExpiredMedicines;