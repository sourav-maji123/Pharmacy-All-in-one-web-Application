import DashboardCards from "../components/dashboard/DashboardCards";
import RecentMedicines from "../components/dashboard/RecentMedicines";

function Dashboard() {
  return (
    <div className="space-y-8 fade">

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-800 dark:text-white">
            Dashboard
          </h1>

          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Pharmacy Stock & Expiry Overview
          </p>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md border border-gray-100 dark:border-slate-700 px-4 py-3">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Today
          </p>
          <p className="font-bold text-slate-800 dark:text-white">
            {new Date().toLocaleDateString()}
          </p>
        </div>

      </div>

      <DashboardCards />

      <RecentMedicines />

    </div>
  );
}

export default Dashboard;