import { useState } from "react";
import SearchBar from "../components/common/SearchBar";
import MedicineTable from "../components/medicine/MedicineTable";

function Medicines() {
  const [search, setSearch] = useState("");

  return (
    <div className="space-y-6">

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">

        <div>
          <h1 className="text-3xl font-bold text-slate-800">
            Medicines
          </h1>

          <p className="text-gray-500 mt-1">
            Manage all medicines in your pharmacy.
          </p>
        </div>

        <SearchBar
          search={search}
          setSearch={setSearch}
        />

      </div>

      <div className="bg-white rounded-xl shadow-md p-4">
        <MedicineTable search={search} />
      </div>

    </div>
  );
}

export default Medicines;