import { useEffect, useState } from "react";
import {
  Routes,
  Route,
  Outlet,
} from "react-router-dom";

// Layout
import Navbar from "./components/layout/Navbar";
import Sidebar from "./components/layout/Sidebar";
import Footer from "./components/layout/Footer";

// Pages
import Dashboard from "./pages/Dashboard";
import Medicines from "./pages/Medicines";
import AddMedicine from "./pages/AddMedicine";
import EditMedicine from "./pages/EditMedicine";
import Sales from "./pages/Sales";
import LowStock from "./pages/LowStock";
import ExpiredMedicines from "./pages/ExpiredMedicines";
import About from "./pages/About";

import Billing from "./pages/Billing/Billing";
import Customers from "./pages/Customers/Customers";

// Auth
import Login from "./pages/Auth/Login";
import Register from "./pages/Auth/Register";

import ProtectedRoute from "./components/auth/ProtectedRoute";
import RoleRoute from "./components/auth/RoleRoute";

// ======================================
// Main Layout
// ======================================

function MainLayout({ darkMode, setDarkMode }) {
  return (
    <>
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      <div className="flex">
        <Sidebar />

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>

      <Footer />
    </>
  );
}

// ======================================
// App
// ======================================

function App() {
  const [darkMode, setDarkMode] =
    useState(
      localStorage.getItem("theme") === "dark"
    );

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add(
        "dark"
      );

      localStorage.setItem(
        "theme",
        "dark"
      );
    } else {
      document.documentElement.classList.remove(
        "dark"
      );

      localStorage.setItem(
        "theme",
        "light"
      );
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 transition-all duration-300">

      <Routes>

        {/* ==========================
            Public
        ========================== */}

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />

        {/* ==========================
            Protected
        ========================== */}

        <Route element={<ProtectedRoute />}>

          <Route
            element={
              <MainLayout
                darkMode={darkMode}
                setDarkMode={setDarkMode}
              />
            }
          >

            <Route
              path="/"
              element={<Dashboard />}
            />

            <Route
              path="/dashboard"
              element={<Dashboard />}
            />

            <Route
              path="/medicines"
              element={<Medicines />}
            />

            <Route
              path="/add-medicine"
              element={<AddMedicine />}
            />

            <Route
              path="/edit/:id"
              element={<EditMedicine />}
            />

            <Route
              path="/sales"
              element={<Sales />}
            />

            <Route
              path="/billing"
              element={<Billing />}
            />

            <Route
              path="/customers"
              element={<Customers />}
            />

            <Route
              path="/low-stock"
              element={<LowStock />}
            />

            <Route
              path="/expired"
              element={<ExpiredMedicines />}
            />

            <Route
              path="/about"
              element={<About />}
            />

            {/* Admin Only */}

            <Route
              element={
                <RoleRoute
                  allowedRoles={["Admin"]}
                />
              }
            >
              <Route
                path="/users"
                element={
                  <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6">
                    <h1 className="text-2xl font-bold text-slate-800 dark:text-white">
                      User Management
                    </h1>

                    <p className="text-gray-500 dark:text-gray-400 mt-2">
                      Admin-only section.
                    </p>
                  </div>
                }
              />
            </Route>

          </Route>

        </Route>

      </Routes>

    </div>
  );
}

export default App;