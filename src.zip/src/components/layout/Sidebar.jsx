import { NavLink } from "react-router-dom";

import {
  FaChartPie,
  FaCapsules,
  FaPlusCircle,
  FaCashRegister,
  FaFileInvoiceDollar,
  FaUsers,
  FaExclamationTriangle,
  FaCalendarTimes,
  FaInfoCircle,
  FaUserCog,
  FaSignOutAlt,
} from "react-icons/fa";

function Sidebar() {
  const token = localStorage.getItem("token");

  const user = JSON.parse(
    localStorage.getItem("user") || "null"
  );

  const role = user?.role;

  const menuItems = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: <FaChartPie />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Medicines",
      path: "/medicines",
      icon: <FaCapsules />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Add Medicine",
      path: "/add-medicine",
      icon: <FaPlusCircle />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Sales",
      path: "/sales",
      icon: <FaCashRegister />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Billing",
      path: "/billing",
      icon: <FaFileInvoiceDollar />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Customers",
      path: "/customers",
      icon: <FaUsers />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Low Stock",
      path: "/low-stock",
      icon: <FaExclamationTriangle />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "Expired",
      path: "/expired",
      icon: <FaCalendarTimes />,
      roles: ["Admin", "Staff"],
    },

    {
      name: "User Management",
      path: "/users",
      icon: <FaUserCog />,
      roles: ["Admin"],
    },

    {
      name: "About",
      path: "/about",
      icon: <FaInfoCircle />,
      roles: ["Admin", "Staff"],
    },
  ];

  const visibleItems = menuItems.filter(
    (item) =>
      role && item.roles.includes(role)
  );

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    window.location.href = "/login";
  };

  return (
    <aside className="w-64 min-h-[calc(100vh-64px)] bg-slate-900 text-white shadow-lg">

      {/* Header */}

      <div className="p-6 border-b border-slate-700">
        <h2 className="text-xl font-bold">
          Pharmacy Admin
        </h2>

        <p className="text-sm text-slate-400 mt-1">
          Pharmacy Management
        </p>

        {user && (
          <div className="mt-3">

            <p className="text-sm font-semibold text-white">
              {user.name}
            </p>

            <span className="inline-block mt-1 px-2 py-1 rounded text-xs bg-blue-600">
              {user.role}
            </span>

          </div>
        )}
      </div>

      {/* Menu */}

      <nav className="p-4">

        {visibleItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-all duration-300 ${
                isActive
                  ? "bg-blue-600 text-white shadow-md"
                  : "text-slate-300 hover:bg-slate-800 hover:text-white"
              }`
            }
          >
            <span className="text-lg">
              {item.icon}
            </span>

            <span className="font-medium">
              {item.name}
            </span>
          </NavLink>
        ))}

        {/* Logout */}

        {token && (
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg mt-4 text-red-400 hover:bg-red-500 hover:text-white transition"
          >
            <FaSignOutAlt />
            <span className="font-medium">
              Logout
            </span>
          </button>
        )}

      </nav>
    </aside>
  );
}

export default Sidebar;