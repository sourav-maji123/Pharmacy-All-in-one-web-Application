import {
  FaCapsules,
  FaGithub,
  FaLinkedin,
  FaHeart,
} from "react-icons/fa";

function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-slate-700 transition-all duration-300">

      <div className="max-w-full px-6 py-5">

        <div className="flex flex-col lg:flex-row items-center justify-between gap-5">

          {/* Left */}
          <div className="flex items-center gap-3">

            <div className="w-11 h-11 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg">
              <FaCapsules size={20} />
            </div>

            <div>

              <h2 className="font-bold text-slate-800 dark:text-white">
                Pharmacy Stock & Expiry Tracker
              </h2>

              <p className="text-sm text-gray-500 dark:text-gray-400">
                Manage medicines, stock & expiry easily.
              </p>

            </div>

          </div>

          {/* Center */}
          <div className="text-center">

            <p className="text-sm text-gray-500 dark:text-gray-400">

              © {year} All Rights Reserved

            </p>

            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">

              Developed with{" "}

              <FaHeart
                className="inline text-red-500 mx-1"
              />

              by{" "}

              <span className="font-semibold text-blue-600">
                Sourav Maji
              </span>

            </p>

          </div>

          {/* Right */}

          <div className="flex items-center gap-3">

            <a
              href="#"
              className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 hover:bg-blue-600 hover:text-white flex items-center justify-center transition"
            >
              <FaGithub />
            </a>

            <a
              href="#"
              className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 hover:bg-blue-600 hover:text-white flex items-center justify-center transition"
            >
              <FaLinkedin />
            </a>

          </div>

        </div>

      </div>

    </footer>
  );
}

export default Footer;