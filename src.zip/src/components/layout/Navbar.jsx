import { useState, useEffect } from "react";
import { FaCapsules, FaBell, FaMoon, FaSun } from "react-icons/fa";
import { FiUser } from "react-icons/fi";
import api from "../../services/api";

function Navbar() {
  const [darkMode, setDarkMode] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const res = await api.get("/medicines");

      const today = new Date();

      const list = res.data.filter((medicine) => {
        const expiry = new Date(medicine.expiry);

        const diff = Math.ceil(
          (expiry - today) / (1000 * 60 * 60 * 24)
        );

        return diff <= 7;
      });

      setNotifications(list);

    } catch (err) {
      console.log(err);
    }
  };

  const toggleDarkMode = () => {
    if (darkMode) {
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.add("dark");
    }

    setDarkMode(!darkMode);
  };

  return (
    <header className="h-16 bg-white dark:bg-slate-900 shadow-md px-6 flex justify-between items-center">

      {/* Logo */}
      <div className="flex items-center gap-3">
        <FaCapsules className="text-3xl text-blue-600" />

        <div>
          <h1 className="font-bold text-xl dark:text-white">
            Pharmacy Tracker
          </h1>

          <p className="text-xs text-gray-500">
            Stock & Expiry Management
          </p>
        </div>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-4">

        {/* Notification */}

        <div className="relative">

          <button
            onClick={() =>
              setShowNotifications(!showNotifications)
            }
            className="relative w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
          >
            <FaBell />

            {notifications.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full text-xs w-5 h-5 flex items-center justify-center">
                {notifications.length}
              </span>
            )}
          </button>

          {showNotifications && (

            <div className="absolute right-0 mt-3 w-80 bg-white rounded-lg shadow-xl border z-50">

              <div className="p-3 border-b font-semibold">
                Notifications
              </div>

              {notifications.length === 0 ? (

                <div className="p-4 text-gray-500">
                  No Notifications
                </div>

              ) : (

                notifications.map((medicine) => {

                  const diff = Math.ceil(
                    (new Date(medicine.expiry) - new Date()) /
                    (1000 * 60 * 60 * 24)
                  );

                  return (

                    <div
                      key={medicine._id}
                      className="border-b p-3 hover:bg-gray-100"
                    >

                      <h3 className="font-semibold">
                        {medicine.name}
                      </h3>

                      <p className="text-sm text-gray-500">

                        {diff < 0
                          ? "❌ Expired"
                          : diff === 0
                          ? "⚠ Expires Today"
                          : `⏰ Expires in ${diff} day(s)`}

                      </p>

                    </div>

                  );

                })

              )}

            </div>

          )}

        </div>

        {/* Dark Mode */}

        <button
          onClick={toggleDarkMode}
          className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
        >

          {darkMode ? <FaSun /> : <FaMoon />}

        </button>

        {/* Admin */}

        <div className="flex items-center gap-3">

          <div className="hidden md:block text-right">

            <h3 className="font-semibold dark:text-white">
              Admin
            </h3>

            <p className="text-xs text-gray-500">
              Pharmacy Manager
            </p>

          </div>

          <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center">

            <FiUser />

          </div>

        </div>

      </div>

    </header>
  );
}

export default Navbar;