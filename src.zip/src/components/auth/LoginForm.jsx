import { useState } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api";

function LoginForm() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      alert("Please enter email and password");
      return;
    }

    try {
      setLoading(true);

      const res = await api.post("/auth/login", formData);

      localStorage.setItem("token", res.data.token);

      localStorage.setItem(
        "user",
        JSON.stringify(res.data.user)
      );

      alert("Login Successful");

      window.location.href = "/dashboard";
    } catch (error) {
      console.error("Login Error:", error);

      alert(
        error.response?.data?.message ||
          "Login failed"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-5"
    >
      {/* Email */}

      <div>
        <label className="block mb-2 font-medium text-slate-700 dark:text-gray-200">
          Email
        </label>

        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Enter your email"
          autoComplete="email"
          className="w-full border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white"
        />
      </div>

      {/* Password */}

      <div>
        <label className="block mb-2 font-medium text-slate-700 dark:text-gray-200">
          Password
        </label>

        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          placeholder="Enter your password"
          autoComplete="current-password"
          className="w-full border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white"
        />
      </div>

      {/* Login Button */}

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold py-3 rounded-lg transition"
      >
        {loading ? "Signing In..." : "Login"}
      </button>

      {/* Register Link */}

      <div className="text-center pt-2">

        <p className="text-sm text-gray-500 dark:text-gray-400">
          Don't have an account?
        </p>

        <Link
          to="/register"
          className="inline-block mt-1 text-blue-600 hover:text-blue-700 font-semibold"
        >
          Create New Account
        </Link>

      </div>

    </form>
  );
}

export default LoginForm;