import { useRef } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

function PrintInvoice({ invoice }) {
  const invoiceRef = useRef();

  if (!invoice) {
    return null;
  }

  const formatDate = (date) => {
    if (!date) return "-";

    return new Date(date).toLocaleString();
  };

  const handlePrint = () => {
    const printContent = invoiceRef.current;

    if (!printContent) return;

    const printWindow = window.open(
      "",
      "_blank",
      "width=900,height=700"
    );

    if (!printWindow) {
      alert("Please allow pop-ups to print the invoice.");
      return;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${invoice.invoiceNumber}</title>

          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 30px;
              color: #111;
            }

            .invoice {
              max-width: 800px;
              margin: auto;
            }

            .header {
              text-align: center;
              margin-bottom: 25px;
            }

            .header h1 {
              margin: 0;
              font-size: 28px;
            }

            .header p {
              margin: 5px 0;
              color: #555;
            }

            .info {
              display: flex;
              justify-content: space-between;
              margin-bottom: 20px;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }

            th,
            td {
              border: 1px solid #ddd;
              padding: 10px;
              text-align: left;
            }

            th {
              background: #2563eb;
              color: white;
            }

            .summary {
              width: 320px;
              margin-left: auto;
              margin-top: 25px;
            }

            .summary-row {
              display: flex;
              justify-content: space-between;
              padding: 6px 0;
            }

            .grand-total {
              font-size: 20px;
              font-weight: bold;
              border-top: 2px solid #111;
              margin-top: 8px;
              padding-top: 10px;
            }

            .footer {
              text-align: center;
              margin-top: 40px;
              color: #666;
            }

            @media print {
              body {
                padding: 0;
              }
            }
          </style>
        </head>

        <body>

          ${printContent.innerHTML}

        </body>
      </html>
    `);

    printWindow.document.close();

    printWindow.onload = () => {
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    };
  };

  const handleDownloadPDF = async () => {
    const element = invoiceRef.current;

    if (!element) return;

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
      });

      const imageData = canvas.toDataURL("image/png");

      const pdf = new jsPDF("p", "mm", "a4");

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      const margin = 10;

      const contentWidth =
        pageWidth - margin * 2;

      const contentHeight =
        (canvas.height * contentWidth) /
        canvas.width;

      let heightLeft = contentHeight;
      let position = margin;

      pdf.addImage(
        imageData,
        "PNG",
        margin,
        position,
        contentWidth,
        contentHeight
      );

      heightLeft -=
        pageHeight - margin * 2;

      while (heightLeft > 0) {
        position =
          position -
          (pageHeight - margin * 2);

        pdf.addPage();

        pdf.addImage(
          imageData,
          "PNG",
          margin,
          position,
          contentWidth,
          contentHeight
        );

        heightLeft -=
          pageHeight - margin * 2;
      }

      pdf.save(
        `${invoice.invoiceNumber}.pdf`
      );
    } catch (error) {
      console.error(
        "PDF Download Error:",
        error
      );

      alert(
        "Failed to generate PDF invoice."
      );
    }
  };

  return (
    <div className="space-y-4">

      {/* ==========================
          Invoice Preview
      ========================== */}

      <div
        ref={invoiceRef}
        className="bg-white text-black rounded-xl p-8 shadow-md"
      >

        <div className="header text-center mb-8">

          <h1 className="text-3xl font-bold">
            PHARMACY
          </h1>

          <p className="text-gray-600">
            Pharmacy Management & Billing System
          </p>

          <p className="text-gray-500 text-sm mt-2">
            Invoice: {invoice.invoiceNumber}
          </p>

        </div>

        {/* Customer Info */}

        <div className="grid grid-cols-2 gap-6 mb-6">

          <div>

            <h3 className="font-semibold mb-2">
              Customer
            </h3>

            <p>
              {invoice.customerName ||
                "Walk-in Customer"}
            </p>

            {invoice.customerPhone && (
              <p className="text-gray-600">
                {invoice.customerPhone}
              </p>
            )}

          </div>

          <div className="text-right">

            <h3 className="font-semibold mb-2">
              Invoice Date
            </h3>

            <p>
              {formatDate(
                invoice.invoiceDate ||
                  invoice.createdAt
              )}
            </p>

            <p className="mt-2">
              Payment:{" "}
              <strong>
                {invoice.paymentMethod ||
                  "Cash"}
              </strong>
            </p>

          </div>

        </div>

        {/* Medicines */}

        <div className="overflow-x-auto">

          <table className="w-full border-collapse">

            <thead>

              <tr className="bg-blue-600 text-white">

                <th className="border p-3 text-left">
                  Medicine
                </th>

                <th className="border p-3 text-center">
                  Qty
                </th>

                <th className="border p-3 text-right">
                  Price
                </th>

                <th className="border p-3 text-right">
                  Total
                </th>

              </tr>

            </thead>

            <tbody>

              {invoice.items?.map(
                (item, index) => (
                  <tr key={index}>

                    <td className="border p-3">
                      {item.medicineName}
                    </td>

                    <td className="border p-3 text-center">
                      {item.quantity}
                    </td>

                    <td className="border p-3 text-right">
                      ₹{item.price}
                    </td>

                    <td className="border p-3 text-right">
                      ₹{item.total}
                    </td>

                  </tr>
                )
              )}

            </tbody>

          </table>

        </div>

        {/* Summary */}

        <div className="w-full md:w-80 ml-auto mt-6 space-y-2">

          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>
              ₹
              {Number(
                invoice.subtotal || 0
              ).toFixed(2)}
            </span>
          </div>

          <div className="flex justify-between">
            <span>Discount</span>
            <span>
              ₹
              {Number(
                invoice.discount || 0
              ).toFixed(2)}
            </span>
          </div>

          <div className="flex justify-between">
            <span>Tax</span>
            <span>
              ₹
              {Number(
                invoice.tax || 0
              ).toFixed(2)}
            </span>
          </div>

          <div className="flex justify-between border-t-2 border-black pt-3 text-xl font-bold">

            <span>
              Grand Total
            </span>

            <span className="text-green-600">
              ₹
              {Number(
                invoice.grandTotal || 0
              ).toFixed(2)}
            </span>

          </div>

        </div>

        {/* Footer */}

        <div className="text-center mt-10 text-gray-500 text-sm">

          <p>
            Thank you for your purchase.
          </p>

          <p className="mt-1">
            Please keep this invoice for your records.
          </p>

        </div>

      </div>

      {/* ==========================
          Buttons
      ========================== */}

      <div className="flex flex-wrap gap-3 justify-end">

        <button
          onClick={handlePrint}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-semibold"
        >
          🖨️ Print Invoice
        </button>

        <button
          onClick={handleDownloadPDF}
          className="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-lg font-semibold"
        >
          📄 Download PDF
        </button>

      </div>

    </div>
  );
}

export default PrintInvoice;