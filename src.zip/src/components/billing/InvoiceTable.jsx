import { useEffect, useState } from "react";
import api from "../../services/api";
import PrintInvoice from "./PrintInvoice";

function InvoiceTable() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [showInvoice, setShowInvoice] = useState(false);

  // ==========================
  // FETCH INVOICES
  // ==========================

  const fetchInvoices = async () => {
    try {
      setLoading(true);

      const res = await api.get("/invoices");

      setInvoices(res.data.invoices || []);
    } catch (error) {
      console.error("Fetch Invoice Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to load invoices"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  // ==========================
  // VIEW INVOICE
  // ==========================

  const viewInvoice = (invoice) => {
    setSelectedInvoice(invoice);
    setShowInvoice(true);
  };

  // ==========================
  // CLOSE INVOICE
  // ==========================

  const closeInvoice = () => {
    setSelectedInvoice(null);
    setShowInvoice(false);
  };

  // ==========================
  // DELETE INVOICE
  // ==========================

  const deleteInvoice = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this invoice?\n\nStock will be restored automatically."
    );

    if (!confirmDelete) return;

    try {
      await api.delete(`/invoices/${id}`);

      alert("Invoice deleted successfully");

      if (selectedInvoice?._id === id) {
        closeInvoice();
      }

      fetchInvoices();
    } catch (error) {
      console.error("Delete Invoice Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to delete invoice"
      );
    }
  };

  // ==========================
  // FORMAT DATE
  // ==========================

  const formatDate = (date) => {
    if (!date) return "-";

    return new Date(date).toLocaleString();
  };

  return (
    <>
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md overflow-hidden">

        {/* ==========================
            HEADER
        ========================== */}

        <div className="p-5 border-b dark:border-slate-700">

          <h2 className="text-xl font-bold text-slate-800 dark:text-white">
            Invoice History
          </h2>

          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            View, print, download and manage generated invoices.
          </p>

        </div>

        {/* ==========================
            TABLE
        ========================== */}

        <div className="overflow-x-auto">

          <table className="w-full">

            <thead className="bg-blue-600 text-white">

              <tr>

                <th className="p-3 text-left">
                  Invoice
                </th>

                <th className="text-left">
                  Customer
                </th>

                <th className="text-center">
                  Items
                </th>

                <th className="text-center">
                  Amount
                </th>

                <th className="text-center">
                  Payment
                </th>

                <th className="text-center">
                  Date
                </th>

                <th className="text-center">
                  Actions
                </th>

              </tr>

            </thead>

            <tbody>

              {loading ? (
                <tr>
                  <td
                    colSpan="7"
                    className="text-center p-10 text-gray-500"
                  >
                    Loading invoices...
                  </td>
                </tr>
              ) : invoices.length === 0 ? (
                <tr>
                  <td
                    colSpan="7"
                    className="text-center p-10 text-gray-500"
                  >
                    No invoices found
                  </td>
                </tr>
              ) : (
                invoices.map((invoice) => (
                  <tr
                    key={invoice._id}
                    className="border-b dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-800"
                  >

                    {/* Invoice */}

                    <td className="p-3 font-semibold text-blue-600">
                      {invoice.invoiceNumber}
                    </td>

                    {/* Customer */}

                    <td className="dark:text-white">

                      <div className="font-medium">
                        {invoice.customerName ||
                          "Walk-in Customer"}
                      </div>

                      {invoice.customerPhone && (
                        <div className="text-xs text-gray-500">
                          {invoice.customerPhone}
                        </div>
                      )}

                    </td>

                    {/* Items */}

                    <td className="text-center">
                      {invoice.items?.length || 0}
                    </td>

                    {/* Amount */}

                    <td className="text-center font-bold text-green-600">
                      ₹
                      {Number(
                        invoice.grandTotal || 0
                      ).toFixed(2)}
                    </td>

                    {/* Payment */}

                    <td className="text-center">

                      <span className="inline-block px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm font-medium">
                        {invoice.paymentMethod || "Cash"}
                      </span>

                    </td>

                    {/* Date */}

                    <td className="text-center text-sm dark:text-gray-300">
                      {formatDate(
                        invoice.invoiceDate ||
                          invoice.createdAt
                      )}
                    </td>

                    {/* Actions */}

                    <td className="text-center">

                      <div className="flex flex-wrap justify-center gap-2">

                        {/* View */}

                        <button
                          onClick={() =>
                            viewInvoice(invoice)
                          }
                          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded"
                        >
                          View
                        </button>

                        {/* Delete */}

                        <button
                          onClick={() =>
                            deleteInvoice(invoice._id)
                          }
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded"
                        >
                          Delete
                        </button>

                      </div>

                    </td>

                  </tr>
                ))
              )}

            </tbody>

          </table>

        </div>

      </div>

      {/* ==========================
          INVOICE PREVIEW MODAL
      ========================== */}

      {showInvoice && selectedInvoice && (

        <div className="fixed inset-0 bg-black/60 z-50 overflow-y-auto p-4">

          <div className="max-w-5xl mx-auto mt-6 mb-6">

            {/* Close */}

            <div className="flex justify-end mb-3">

              <button
                onClick={closeInvoice}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-semibold"
              >
                ✕ Close
              </button>

            </div>

            {/* Invoice */}

            <PrintInvoice
              invoice={selectedInvoice}
            />

          </div>

        </div>

      )}

    </>
  );
}

export default InvoiceTable;