import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api";

function MedicineTable() {
  const [medicines, setMedicines] = useState([]);
  const [selectedMedicine, setSelectedMedicine] = useState(null);
  const [sellQty, setSellQty] = useState(1);
  const [showSellModal, setShowSellModal] = useState(false);

  useEffect(() => {
    fetchMedicines();
  }, []);

  const fetchMedicines = async () => {
    try {
      const res = await api.get("/medicines");
      setMedicines(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const deleteMedicine = async (id) => {
    if (!window.confirm("Are you sure you want to delete this medicine?"))
      return;

    try {
      await api.delete(`/medicines/${id}`);
      alert("Medicine Deleted Successfully");
      fetchMedicines();
    } catch (err) {
      console.error(err);
      alert("Delete Failed");
    }
  };

  const handleSell = (medicine) => {
    setSelectedMedicine(medicine);
    setSellQty(1);
    setShowSellModal(true);
  };

  const confirmSale = async () => {
    if (!selectedMedicine) return;

    if (sellQty <= 0) {
      alert("Please enter a valid quantity");
      return;
    }

    if (sellQty > selectedMedicine.quantity) {
      alert("Not enough stock available");
      return;
    }

    try {
      await api.post("/sales", {
        medicineId: selectedMedicine._id,
        quantity: sellQty,
      });

      alert("Medicine Sold Successfully");

      setShowSellModal(false);
      setSelectedMedicine(null);
      setSellQty(1);

      fetchMedicines();
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Sale Failed");
    }
  };

  return (
    <>
  <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md overflow-x-auto">
    <table className="w-full">
      <thead className="bg-blue-600 text-white">
        <tr>
          <th className="p-3">Name</th>
          <th>Company</th>
          <th>Category</th>
          <th>Price</th>
          <th>Qty</th>
          <th>Expiry</th>
          <th>Actions</th>
        </tr>
      </thead>

      <tbody>
        {medicines.length === 0 ? (
          <tr>
            <td colSpan="7" className="text-center p-6">
              No Medicines Found
            </td>
          </tr>
        ) : (
          medicines.map((medicine) => (
            <tr key={medicine._id} className="border-b text-center">
              <td className="p-3">{medicine.name}</td>

              <td>{medicine.company}</td>

              <td>{medicine.category}</td>

              <td>₹{medicine.price}</td>

              <td>{medicine.quantity}</td>

              <td>
                {new Date(medicine.expiry).toLocaleDateString()}
              </td>

              <td className="space-x-2">
                <button
                  onClick={() => handleSell(medicine)}
                  className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
                >
                  Sell
                </button>

                <Link
                  to={`/edit/${medicine._id}`}
                  className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600"
                >
                  Edit
                </Link>

                <button
                  onClick={() => deleteMedicine(medicine._id)}
                  className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>

  {/* Sell Modal */}
  {showSellModal && selectedMedicine && (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-96 p-6">

        <h2 className="text-2xl font-bold mb-5 dark:text-white">
          Sell Medicine
        </h2>

        <div className="space-y-4">

          <div>
            <label className="font-semibold">Medicine</label>
            <input
              type="text"
              value={selectedMedicine.name}
              disabled
              className="w-full border rounded-lg p-2 mt-1"
            />
          </div>

          <div>
            <label className="font-semibold">Available Stock</label>
            <input
              type="text"
              value={selectedMedicine.quantity}
              disabled
              className="w-full border rounded-lg p-2 mt-1"
            />
          </div>

          <div>
            <label className="font-semibold">Quantity</label>
            <input
              type="number"
              min="1"
              max={selectedMedicine.quantity}
              value={sellQty}
              onChange={(e) =>
                setSellQty(Math.max(1, Number(e.target.value)))
              }
              className="w-full border rounded-lg p-2 mt-1"
            />
          </div>

          <div>
            <label className="font-semibold">Total Price</label>
            <input
              type="text"
              disabled
              value={`₹${selectedMedicine.price * sellQty}`}
              className="w-full border rounded-lg p-2 mt-1 bg-gray-100"
            />
          </div>

        </div>

        <div className="flex justify-end gap-3 mt-6">

          <button
            onClick={() => {
              setShowSellModal(false);
              setSelectedMedicine(null);
              setSellQty(1);
            }}
            className="px-4 py-2 rounded bg-gray-500 text-white hover:bg-gray-600"
          >
            Cancel
          </button>

          <button
            onClick={confirmSale}
            className="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700"
          >
            Confirm Sale
          </button>

        </div>

      </div>
    </div>
  )}
</>

);
}

export default MedicineTable;