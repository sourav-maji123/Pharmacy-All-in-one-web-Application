import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../../services/api";

function MedicineForm({ editId }) {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    company: "",
    category: "",
    price: "",
    quantity: "",
    expiry: "",
  });

  useEffect(() => {
    if (editId) {
      fetchMedicine();
    }
  }, [editId]);

  const fetchMedicine = async () => {
    try {
      const res = await api.get(`/medicines/${editId}`);

      setForm({
        ...res.data,
        expiry: res.data.expiry.split("T")[0],
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await api.put(`/medicines/${editId}`, form);
        alert("Medicine Updated Successfully");
      } else {
        await api.post("/medicines", form);
        alert("Medicine Added Successfully");
      }

      navigate("/medicines");
    } catch (err) {
      console.error(err);
      alert("Operation Failed");
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="grid md:grid-cols-2 gap-5"
    >
      <input
        className="border p-3 rounded-lg"
        name="name"
        value={form.name}
        onChange={handleChange}
        placeholder="Medicine Name"
        required
      />

      <input
        className="border p-3 rounded-lg"
        name="company"
        value={form.company}
        onChange={handleChange}
        placeholder="Company"
        required
      />

      <input
        className="border p-3 rounded-lg"
        name="category"
        value={form.category}
        onChange={handleChange}
        placeholder="Category"
        required
      />

      <input
        className="border p-3 rounded-lg"
        name="price"
        type="number"
        value={form.price}
        onChange={handleChange}
        placeholder="Price"
        required
      />

      <input
        className="border p-3 rounded-lg"
        name="quantity"
        type="number"
        value={form.quantity}
        onChange={handleChange}
        placeholder="Quantity"
        required
      />

      <input
        className="border p-3 rounded-lg"
        name="expiry"
        type="date"
        value={form.expiry}
        onChange={handleChange}
        required
      />

      <button
        type="submit"
        className="bg-blue-600 text-white rounded-lg p-3 md:col-span-2 hover:bg-blue-700"
      >
        {editId ? "Update Medicine" : "Save Medicine"}
      </button>
    </form>
  );
}

export default MedicineForm;