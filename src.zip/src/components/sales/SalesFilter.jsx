function SalesFilter({
  filter,
  setFilter,
  fromDate,
  setFromDate,
  toDate,
  setToDate,
}) {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-5 mb-6">

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">

        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-white">
            Sales Report
          </h2>

          <p className="text-gray-500 text-sm mt-1">
            View sales by date range
          </p>
        </div>

        <div className="flex flex-wrap gap-3">

          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border rounded-lg px-4 py-2 dark:bg-slate-800 dark:text-white"
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="week">Last 7 Days</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
            <option value="custom">Custom Range</option>
          </select>

          {filter === "custom" && (
            <>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="border rounded-lg px-3 py-2 dark:bg-slate-800 dark:text-white"
              />

              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="border rounded-lg px-3 py-2 dark:bg-slate-800 dark:text-white"
              />
            </>
          )}

        </div>

      </div>

    </div>
  );
}

export default SalesFilter;