import { useEffect, useState } from "react";
import api from "../../services/api";

import {
  FaMoneyBillWave,
  FaShoppingCart,
  FaCapsules,
  FaFileInvoiceDollar,
} from "react-icons/fa";

function SalesCard({ filter, fromDate, toDate }) {
  const [summary, setSummary] = useState({
    revenue: 0,
    sales: 0,
    medicines: 0,
  });

  useEffect(() => {
    fetchReport();
  }, [filter, fromDate, toDate]);

  const fetchReport = async () => {
    try {
      let url = `/reports?filter=${filter}`;

      if (
        filter === "custom" &&
        fromDate &&
        toDate
      ) {
        url = `/reports?filter=custom&from=${fromDate}&to=${toDate}`;
      }

      const res = await api.get(url);

      setSummary(res.data.summary);
    } catch (err) {
      console.error(err);
    }
  };

  const cards = [
    {
      title: "Revenue",
      value: `₹${summary.revenue}`,
      icon: <FaMoneyBillWave />,
      color: "bg-green-500",
    },
    {
      title: "Sales",
      value: summary.sales,
      icon: <FaShoppingCart />,
      color: "bg-blue-500",
    },
    {
      title: "Medicines Sold",
      value: summary.medicines,
      icon: <FaCapsules />,
      color: "bg-purple-500",
    },
    {
      title: "Invoices",
      value: summary.sales,
      icon: <FaFileInvoiceDollar />,
      color: "bg-orange-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <div
          key={index}
          className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-5 flex items-center justify-between hover:shadow-xl transition-all"
        >
          <div>
            <p className="text-gray-500 text-sm">
              {card.title}
            </p>

            <h2 className="text-3xl font-bold mt-2 text-slate-800 dark:text-white">
              {card.value}
            </h2>
          </div>

          <div
            className={`${card.color} text-white text-3xl w-16 h-16 rounded-full flex items-center justify-center`}
          >
            {card.icon}
          </div>
        </div>
      ))}
    </div>
  );
}

export default SalesCard;