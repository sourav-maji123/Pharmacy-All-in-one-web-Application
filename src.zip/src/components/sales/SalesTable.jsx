import { useEffect, useState } from "react";
import api from "../../services/api";

function SalesTable({ filter, fromDate, toDate }) {
  const [sales, setSales] = useState([]);

  useEffect(() => {
    fetchSales();
  }, [filter, fromDate, toDate]);

  const fetchSales = async () => {
    try {
      let url = `/reports?filter=${filter}`;

      if (
        filter === "custom" &&
        fromDate &&
        toDate
      ) {
        url = `/reports?filter=custom&from=${fromDate}&to=${toDate}`;
      }

      const res = await api.get(url);

      setSales(res.data.sales);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="overflow-x-auto bg-white dark:bg-slate-900 rounded-xl shadow">

      <table className="w-full">

        <thead className="bg-blue-600 text-white">

          <tr>
            <th className="p-3">Medicine</th>
            <th>Company</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Total</th>
            <th>Date</th>
          </tr>

        </thead>

        <tbody>

          {sales.length === 0 ? (
            <tr>
              <td
                colSpan="6"
                className="text-center p-10 text-gray-500"
              >
                No Sales Found
              </td>
            </tr>
          ) : (
            sales.map((sale) => (
              <tr
                key={sale._id}
                className="border-b text-center hover:bg-gray-50 dark:hover:bg-slate-800"
              >
                <td className="p-3">
                  {sale.medicineName}
                </td>

                <td>{sale.company}</td>

                <td>{sale.quantity}</td>

                <td>₹{sale.price}</td>

                <td className="font-semibold text-green-600">
                  ₹{sale.total}
                </td>

                <td>
                  {new Date(
                    sale.createdAt
                  ).toLocaleString()}
                </td>
              </tr>
            ))
          )}

        </tbody>

      </table>

    </div>
  );
}

export default SalesTable;