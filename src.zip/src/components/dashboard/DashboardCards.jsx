import { useEffect, useState } from "react";
import api from "../../services/api";

import {
  FaCapsules,
  FaBoxes,
  FaCalendarTimes,
  FaBuilding,
} from "react-icons/fa";

import StatsCard from "./StatsCard";

function DashboardCards() {
  const [stats, setStats] = useState({
  totalMedicines: 0,
  lowStock: 0,
  expired: 0,
  companies: 0,

  totalSales: 0,
  totalRevenue: 0,
  medicinesSold: 0,
});

  useEffect(() => {
    fetchDashboardData();
  }, []);

 const fetchDashboardData = async () => {
  try {
    const medicineRes = await api.get("/medicines");
    const medicines = medicineRes.data;

    const salesRes = await api.get("/sales/today");
    const sales = salesRes.data;

    const totalMedicines = medicines.length;

    const lowStock = medicines.filter(
      (m) => Number(m.quantity) <= 10
    ).length;

    const today = new Date();

    const expired = medicines.filter(
      (m) => new Date(m.expiry) < today
    ).length;

    const companies = new Set(
      medicines.map((m) => m.company)
    ).size;

    setStats({
      totalMedicines,
      lowStock,
      expired,
      companies,
      totalSales: sales.totalSales || 0,
      totalRevenue: sales.totalRevenue || 0,
      medicinesSold: sales.totalMedicines || 0,
    });
  } catch (err) {
    console.error(err);
  }
};

 return (
  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 fade">

    {/* Existing Cards */}

    <StatsCard
      title="Total Medicines"
      value={stats.totalMedicines}
      subtitle="All medicines in stock"
      icon={<FaCapsules />}
      color="bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300"
    />

    <StatsCard
      title="Low Stock"
      value={stats.lowStock}
      subtitle="Quantity ≤ 10"
      icon={<FaBoxes />}
      color="bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-300"
    />

    <StatsCard
      title="Expired"
      value={stats.expired}
      subtitle="Needs attention"
      icon={<FaCalendarTimes />}
      color="bg-red-100 text-red-600 dark:bg-red-900 dark:text-red-300"
    />

    <StatsCard
      title="Companies"
      value={stats.companies}
      subtitle="Unique suppliers"
      icon={<FaBuilding />}
      color="bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300"
    />

    {/* New Sales Cards */}

    <StatsCard
      title="Today's Sales"
      value={stats.totalSales}
      subtitle="Sales Today"
      icon={<FaCapsules />}
      color="bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300"
    />

    <StatsCard
      title="Revenue"
      value={`₹${stats.totalRevenue}`}
      subtitle="Today's Revenue"
      icon={<FaBoxes />}
      color="bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300"
    />

    <StatsCard
      title="Medicines Sold"
      value={stats.medicinesSold}
      subtitle="Items Sold Today"
      icon={<FaCalendarTimes />}
      color="bg-pink-100 text-pink-600 dark:bg-pink-900 dark:text-pink-300"
    />

  </div>
);
}

export default DashboardCards;