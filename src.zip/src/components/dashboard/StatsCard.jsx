function StatsCard({ title, value, icon, color, subtitle }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-700 p-6 card-hover">

      <div className="flex items-center justify-between">

        <div>

          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
            {title}
          </p>

          <h3 className="text-3xl font-bold mt-2 text-slate-800 dark:text-white">
            {value}
          </h3>

          {subtitle && (
            <p className="text-xs text-gray-400 mt-2">
              {subtitle}
            </p>
          )}

        </div>

        <div
          className={`w-14 h-14 rounded-2xl bg-opacity-10 flex items-center justify-center text-2xl ${color}`}
        >
          {icon}
        </div>

      </div>

    </div>
  );
}

export default StatsCard;