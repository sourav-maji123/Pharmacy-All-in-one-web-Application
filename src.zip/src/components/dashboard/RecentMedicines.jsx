import { useEffect, useState } from "react";
import api from "../../services/api";

function RecentMedicines() {
  const [medicines, setMedicines] = useState([]);

  useEffect(() => {
    fetchRecentMedicines();
  }, []);

  const fetchRecentMedicines = async () => {
    try {
      const res = await api.get("/medicines");

      const sorted = res.data.sort(
        (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
      );

      setMedicines(sorted.slice(0, 5));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-700 p-6 fade">

      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">
            Recent Medicines
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Latest added medicines
          </p>
        </div>

        <span className="text-sm bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300 px-3 py-1 rounded-full font-medium">
          {medicines.length} items
        </span>
      </div>

      {medicines.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">
          No medicines available.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-700/50">
                <th className="p-3 text-left text-sm font-semibold text-slate-700 dark:text-gray-200">Medicine</th>
                <th className="text-left text-sm font-semibold text-slate-700 dark:text-gray-200">Company</th>
                <th className="text-left text-sm font-semibold text-slate-700 dark:text-gray-200">Category</th>
                <th className="text-left text-sm font-semibold text-slate-700 dark:text-gray-200">Qty</th>
                <th className="text-left text-sm font-semibold text-slate-700 dark:text-gray-200">Expiry</th>
              </tr>
            </thead>

            <tbody>
              {medicines.map((medicine) => (
                <tr
                  key={medicine._id}
                  className="border-b border-gray-100 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700/40 transition"
                >
                  <td className="p-3 font-semibold text-slate-800 dark:text-white">
                    {medicine.name}
                  </td>

                  <td className="text-gray-600 dark:text-gray-300">{medicine.company}</td>

                  <td>
                    <span className="bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300 px-2 py-1 rounded-full text-xs font-medium">
                      {medicine.category}
                    </span>
                  </td>

                  <td>
                    <span
                      className={`font-bold ${
                        medicine.quantity <= 10
                          ? "text-red-600 dark:text-red-400"
                          : "text-green-600 dark:text-green-400"
                      }`}
                    >
                      {medicine.quantity}
                    </span>
                  </td>

                  <td className="text-gray-600 dark:text-gray-300">
                    {new Date(medicine.expiry).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default RecentMedicines;