import { useEffect, useState } from "react";
import api from "../../services/api";

function CustomerTable({ refresh }) {
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState("");

  const [editingCustomer, setEditingCustomer] =
    useState(null);

  const [editForm, setEditForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });

  const [loading, setLoading] = useState(true);

  // ===============================
  // FETCH CUSTOMERS
  // ===============================

  const fetchCustomers = async () => {
    try {
      setLoading(true);

      const res = await api.get("/customers");

      setCustomers(res.data.customers || []);
    } catch (error) {
      console.error("Fetch Customers Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to load customers"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, [refresh]);

  // ===============================
  // DELETE CUSTOMER
  // ===============================

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this customer?"
    );

    if (!confirmDelete) return;

    try {
      await api.delete(`/customers/${id}`);

      alert("Customer deleted successfully");

      fetchCustomers();
    } catch (error) {
      console.error("Delete Customer Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to delete customer"
      );
    }
  };

  // ===============================
  // OPEN EDIT MODAL
  // ===============================

  const handleEdit = (customer) => {
    setEditingCustomer(customer);

    setEditForm({
      name: customer.name || "",
      phone: customer.phone || "",
      email: customer.email || "",
      address: customer.address || "",
    });
  };

  // ===============================
  // EDIT INPUT
  // ===============================

  const handleEditChange = (e) => {
    const { name, value } = e.target;

    setEditForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ===============================
  // UPDATE CUSTOMER
  // ===============================

  const handleUpdate = async (e) => {
    e.preventDefault();

    if (!editForm.name.trim()) {
      alert("Customer name is required");
      return;
    }

    if (!editForm.phone.trim()) {
      alert("Customer phone is required");
      return;
    }

    try {
      await api.put(
        `/customers/${editingCustomer._id}`,
        editForm
      );

      alert("Customer updated successfully");

      setEditingCustomer(null);

      fetchCustomers();
    } catch (error) {
      console.error("Update Customer Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to update customer"
      );
    }
  };

  // ===============================
  // SEARCH
  // ===============================

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      customer.phone
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      customer.email
        ?.toLowerCase()
        .includes(search.toLowerCase())
  );

  return (
    <>
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md overflow-hidden">

        {/* Header */}

        <div className="p-5 border-b dark:border-slate-700 flex flex-col md:flex-row md:items-center md:justify-between gap-4">

          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">
              Customers
            </h2>

            <p className="text-sm text-gray-500 dark:text-gray-400">
              Manage your pharmacy customers
            </p>
          </div>

          {/* Search */}

          <input
            type="text"
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
            placeholder="Search customer..."
            className="border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white w-full md:w-72"
          />

        </div>

        {/* Table */}

        <div className="overflow-x-auto">

          <table className="w-full">

            <thead className="bg-blue-600 text-white">

              <tr>
                <th className="p-3 text-left">
                  #
                </th>

                <th className="text-left">
                  Name
                </th>

                <th className="text-left">
                  Phone
                </th>

                <th className="text-left">
                  Email
                </th>

                <th className="text-left">
                  Address
                </th>

                <th className="text-center">
                  Actions
                </th>
              </tr>

            </thead>

            <tbody>

              {loading ? (
                <tr>
                  <td
                    colSpan="6"
                    className="text-center p-8 text-gray-500"
                  >
                    Loading customers...
                  </td>
                </tr>
              ) : filteredCustomers.length === 0 ? (
                <tr>
                  <td
                    colSpan="6"
                    className="text-center p-8 text-gray-500"
                  >
                    No customers found
                  </td>
                </tr>
              ) : (
                filteredCustomers.map(
                  (customer, index) => (
                    <tr
                      key={customer._id}
                      className="border-b dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-800"
                    >

                      <td className="p-3">
                        {index + 1}
                      </td>

                      <td className="font-medium dark:text-white">
                        {customer.name}
                      </td>

                      <td>
                        {customer.phone}
                      </td>

                      <td>
                        {customer.email || "-"}
                      </td>

                      <td>
                        {customer.address || "-"}
                      </td>

                      <td className="text-center">

                        <div className="flex justify-center gap-2">

                          <button
                            onClick={() =>
                              handleEdit(customer)
                            }
                            className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1.5 rounded"
                          >
                            Edit
                          </button>

                          <button
                            onClick={() =>
                              handleDelete(
                                customer._id
                              )
                            }
                            className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded"
                          >
                            Delete
                          </button>

                        </div>

                      </td>

                    </tr>
                  )
                )
              )}

            </tbody>

          </table>

        </div>

      </div>

      {/* ===============================
          EDIT CUSTOMER MODAL
      =============================== */}

      {editingCustomer && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">

          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full max-w-lg p-6">

            <div className="flex items-center justify-between mb-6">

              <h2 className="text-2xl font-bold dark:text-white">
                Edit Customer
              </h2>

              <button
                onClick={() =>
                  setEditingCustomer(null)
                }
                className="text-gray-500 hover:text-red-500 text-2xl"
              >
                ×
              </button>

            </div>

            <form
              onSubmit={handleUpdate}
              className="space-y-4"
            >

              {/* Name */}

              <div>
                <label className="block mb-1 font-medium dark:text-gray-200">
                  Name *
                </label>

                <input
                  type="text"
                  name="name"
                  value={editForm.name}
                  onChange={handleEditChange}
                  className="w-full border rounded-lg px-4 py-2 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>

              {/* Phone */}

              <div>
                <label className="block mb-1 font-medium dark:text-gray-200">
                  Phone *
                </label>

                <input
                  type="tel"
                  name="phone"
                  value={editForm.phone}
                  onChange={handleEditChange}
                  className="w-full border rounded-lg px-4 py-2 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>

              {/* Email */}

              <div>
                <label className="block mb-1 font-medium dark:text-gray-200">
                  Email
                </label>

                <input
                  type="email"
                  name="email"
                  value={editForm.email}
                  onChange={handleEditChange}
                  className="w-full border rounded-lg px-4 py-2 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>

              {/* Address */}

              <div>
                <label className="block mb-1 font-medium dark:text-gray-200">
                  Address
                </label>

                <input
                  type="text"
                  name="address"
                  value={editForm.address}
                  onChange={handleEditChange}
                  className="w-full border rounded-lg px-4 py-2 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>

              {/* Buttons */}

              <div className="flex justify-end gap-3 pt-4">

                <button
                  type="button"
                  onClick={() =>
                    setEditingCustomer(null)
                  }
                  className="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded-lg"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg"
                >
                  Update Customer
                </button>

              </div>

            </form>

          </div>

        </div>
      )}

    </>
  );
}

export default CustomerTable;