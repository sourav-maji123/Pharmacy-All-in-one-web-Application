import { useState } from "react";
import api from "../../services/api";

function CustomerForm({ onCustomerAdded }) {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      alert("Please enter customer name");
      return;
    }

    if (!formData.phone.trim()) {
      alert("Please enter customer phone number");
      return;
    }

    try {
      setLoading(true);

      const res = await api.post("/customers", formData);

      alert(
        res.data.message || "Customer added successfully"
      );

      setFormData({
        name: "",
        phone: "",
        email: "",
        address: "",
      });

      if (onCustomerAdded) {
        onCustomerAdded(res.data.customer);
      }
    } catch (error) {
      console.error("Add Customer Error:", error);

      alert(
        error.response?.data?.message ||
          "Failed to add customer"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-md p-6">

      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-800 dark:text-white">
          Add New Customer
        </h2>

        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Add customer details for billing and purchase history.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 md:grid-cols-2 gap-5"
      >

        {/* Name */}
        <div>
          <label className="block mb-2 font-medium text-slate-700 dark:text-gray-200">
            Customer Name *
          </label>

          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter customer name"
            className="w-full border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white"
          />
        </div>

        {/* Phone */}
        <div>
          <label className="block mb-2 font-medium text-slate-700 dark:text-gray-200">
            Phone Number *
          </label>

          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Enter phone number"
            className="w-full border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white"
          />
        </div>

        {/* Email */}
        <div>
          <label className="block mb-2 font-medium text-slate-700 dark:text-gray-200">
            Email
          </label>

          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter email address"
            className="w-full border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white"
          />
        </div>

        {/* Address */}
        <div>
          <label className="block mb-2 font-medium text-slate-700 dark:text-gray-200">
            Address
          </label>

          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            placeholder="Enter customer address"
            className="w-full border border-gray-300 dark:border-slate-700 rounded-lg px-4 py-2.5 outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-800 dark:text-white"
          />
        </div>

        {/* Button */}
        <div className="md:col-span-2 flex justify-end">

          <button
            type="submit"
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold px-6 py-2.5 rounded-lg transition"
          >
            {loading ? "Adding..." : "Add Customer"}
          </button>

        </div>

      </form>
    </div>
  );
}

export default CustomerForm;